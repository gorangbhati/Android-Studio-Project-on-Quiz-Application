package com.example.quizapplication;

public class Question {
    private int questionTextId;
    private boolean answerTrue;
    private int imageId;

    public Question(int questionTextId, boolean answerTrue, int imageId) {
        this.questionTextId = questionTextId;
        this.answerTrue = answerTrue;
        this.imageId = imageId;
    }

    public int getQuestionTextId() {
        return questionTextId;
    }

    public boolean isAnswerTrue() {
        return answerTrue;
    }

    public int getImageId() {
        return imageId;
    }
}
