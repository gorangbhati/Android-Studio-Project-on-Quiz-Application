package com.example.quizapplication;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class FinalScoreActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_final_score);

        TextView finalScoreText = findViewById(R.id.final_score_text);
        Button restartButton = findViewById(R.id.restart_button);

        Intent intent = getIntent();
        String username = intent.getStringExtra("username");
        int score = intent.getIntExtra("score", 0);
        int totalQuestions = intent.getIntExtra("totalQuestions", 0);

        String scoreMessage = String.format("%s, your score is %d / %d!", username, score, totalQuestions);
        finalScoreText.setText(scoreMessage);

        restartButton.setOnClickListener(v -> {
            Intent restartIntent = new Intent(FinalScoreActivity.this, LoginActivity.class);
            startActivity(restartIntent);
            finish();
        });
    }
}