package com.example.quizapplication;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private Button trueButton, falseButton;
    private TextView questionTextView, answerTextView;
    private ImageView imageView;

    private int correct = 0;
    private int currentQuestionIndex = 0;
    private String username;

    private final Question[] questionBank = {
            new Question(R.string.a, true, R.drawable.f1),
            new Question(R.string.b, false, R.drawable.f2),
            new Question(R.string.c, true, R.drawable.f3),
            new Question(R.string.d, false, R.drawable.f4),
            new Question(R.string.e, false, R.drawable.f5),
            new Question(R.string.f, true, R.drawable.f6),

            // New Questions added here
            new Question(R.string.g, true, R.drawable.f7),
            new Question(R.string.h, false, R.drawable.f8),
            new Question(R.string.i, true, R.drawable.f9),
            new Question(R.string.j, true, R.drawable.f10),
            new Question(R.string.k, true, R.drawable.f11),
            new Question(R.string.l, true, R.drawable.f12),
            new Question(R.string.m, false, R.drawable.f13),
            new Question(R.string.n, true, R.drawable.f14),
            new Question(R.string.o, true, R.drawable.f15),
            new Question(R.string.p, true, R.drawable.f16),
            new Question(R.string.q, true, R.drawable.f17),
            new Question(R.string.r, false, R.drawable.f18),
            new Question(R.string.s, true, R.drawable.f19),
            new Question(R.string.t, false, R.drawable.f20)
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        username = getIntent().getStringExtra("username");

        trueButton = findViewById(R.id.true_button);
        falseButton = findViewById(R.id.false_button);
        questionTextView = findViewById(R.id.question);
        answerTextView = findViewById(R.id.answer);
        imageView = findViewById(R.id.myimage);

        updateQuestion();

        trueButton.setOnClickListener(v -> checkAnswer(true));
        falseButton.setOnClickListener(v -> checkAnswer(false));
    }

    private void updateQuestion() {
        trueButton.setEnabled(true);
        falseButton.setEnabled(true);
        Question q = questionBank[currentQuestionIndex];
        questionTextView.setText(q.getQuestionTextId());
        imageView.setImageResource(q.getImageId());
    }

    private void checkAnswer(boolean userChoice) {
        trueButton.setEnabled(false);
        falseButton.setEnabled(false);

        boolean correctAnswer = questionBank[currentQuestionIndex].isAnswerTrue();
        if (userChoice == correctAnswer) {
            correct++;
            answerTextView.setText("✅ Correct!");
        } else {
            answerTextView.setText("❌ Incorrect!");
        }
        answerTextView.setVisibility(View.VISIBLE);

        new Handler().postDelayed(() -> {
            if (currentQuestionIndex < questionBank.length - 1) {
                currentQuestionIndex++;
                answerTextView.setVisibility(View.INVISIBLE);
                updateQuestion();
            } else {
                showFinalScore();
            }
        }, 1500);
    }

    private void showFinalScore() {
        Intent intent = new Intent(MainActivity.this, FinalScoreActivity.class);
        intent.putExtra("username", username);
        intent.putExtra("score", correct);
        intent.putExtra("totalQuestions", questionBank.length);
        startActivity(intent);
        finish();
    }
}